﻿namespace BaseService.Entities.ObjectsValues
{
    public class Address
    {
        public int Id { get; set; }
        public string? City { get; set; }
        public string? Neighborhood { get; set; }
        public string? Description { get; set; }
    }
}
