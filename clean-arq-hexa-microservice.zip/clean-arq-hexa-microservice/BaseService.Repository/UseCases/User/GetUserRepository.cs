﻿using BaseService.Domain.Interfaces.User;
using BaseService.Entities.ObjectsValues;
using BaseService.Entities.UseCases.User.Request;
using BaseService.Entities.UseCases.User.Response;

namespace BaseService.Repository.UseCases.User
{
    public class GetUserRepository : IGetUserRepository
    {
        public GetUserRepository()
        {
        }

        public async Task<GetUserResponse> GetUser(GetUserRequest getUserRequest)
        {
            return await Task.Run(() =>
            {
                Address address = new()
                {
                    City = "City",
                    Neighborhood = "Neighborhood",
                    Description = "Description",
                };

                GetUserResponse getUserResponse = new()
                {
                    Id = "Identification",
                    Name = "Name",
                    LastName = "LastName",
                    Rol = "Rol",
                    PhoneNumber = "1234567890",
                    Address = address
                };

                return getUserResponse;
            });          
        }
    }
}
