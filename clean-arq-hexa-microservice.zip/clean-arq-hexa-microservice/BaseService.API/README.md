# Information
Microservicio para ....

nombreServicio ====>  www.servicioxterno.com/prueba.aspx

# Documentation 
Descripción de las acciones realizadas.

SwaggerDoc: en el archivo Program.cs , agregar nombre del servicio, título, descripción 

# Build 
ServicioBaseController.cs : representa el nombre del dominio en la que implementa el controlador Ejemplo: ClienteController.cs

InitConfig.cs : carga inicial de componentes.

Program.cs : Clase de inicializacion del servicio, carga centralizada, injection de repositorio, infraestructura.


# Nuget Packages
1. Ardalis.ApiEndpoint (4.1.0)
2. Swashbuckle.AspNetCore(6.2.3)
