﻿using Ardalis.ApiEndpoints;
using BaseService.Domain.Interfaces.User;
using BaseService.Entities.UseCases.User.Request;
using BaseService.Entities.UseCases.User.Response;
using Microsoft.AspNetCore.Mvc;

namespace BaseService.API.EndPoints.User
{
    public class GetUsersController : EndpointBaseAsync
        .WithRequest<GetUserRequest>
        .WithResult<GetUserResponse>
    {
        private readonly IGetUserInfrastructure _getUserInfrastructure;

        public GetUsersController(IGetUserInfrastructure getUserInfrastructure)
        {
            _getUserInfrastructure = getUserInfrastructure;
        }

        [HttpGet("api/getUser")]
        public override async Task<GetUserResponse> HandleAsync(GetUserRequest GetUserRequest, CancellationToken cancellationToken = default)
        {
           return await _getUserInfrastructure.GetUser(GetUserRequest);
        }
    }
}
