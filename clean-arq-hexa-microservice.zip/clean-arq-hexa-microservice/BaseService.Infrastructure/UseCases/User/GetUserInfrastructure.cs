﻿using BaseService.Domain.Interfaces.User;
using BaseService.Entities.UseCases.User.Request;
using BaseService.Entities.UseCases.User.Response;

namespace BaseService.Infrastructure.UseCases.User
{
    public class GetUserInfrastructure : IGetUserInfrastructure
    {
        private readonly IGetUserRepository _repository;


        public GetUserInfrastructure(IGetUserRepository repository) 
        {
            _repository = repository;
        }

        public async Task<GetUserResponse> GetUser(GetUserRequest getUserRequest)
        {
            return await _repository.GetUser(getUserRequest);
        }
    }
}
