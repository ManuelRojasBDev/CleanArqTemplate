﻿/*
 * File: Constants.cs
 * Created At: May 2024
 * Created By: Ing. Manuel Rojas | mrojas@iq-online.com
 *
 * Copyright (c) 2024 IQ-Outsourcing
 */

namespace BaseService.Domain
{
    public class Constants
    {
        public const string MICROSERVICE_NAME = "WSUserAdministration";
    }
}
