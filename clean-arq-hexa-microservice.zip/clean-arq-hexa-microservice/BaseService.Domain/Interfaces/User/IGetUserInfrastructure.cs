﻿using BaseService.Entities.UseCases.User.Request;
using BaseService.Entities.UseCases.User.Response;

namespace BaseService.Domain.Interfaces.User
{
    public interface IGetUserInfrastructure
    {
        Task<GetUserResponse> GetUser(GetUserRequest getUserRequest);
    }
}
