﻿using BaseService.Entities.UseCases.User.Request;
using BaseService.Entities.UseCases.User.Response;

namespace BaseService.Domain.Interfaces.User
{
    public interface IGetUserRepository
    {
        Task<GetUserResponse> GetUser(GetUserRequest getUserRequest);
    }
}
