﻿/*
 * File: Util.cs
 * Created At: May 2024
 * Created By: Ing. Manuel Rojas | mrojas@iq-online.com
 *
 * Copyright (c) 2024 IQ-Outsourcing
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseService.Domain.Utilities
{
    public static class Utilities
    {

    }
}
