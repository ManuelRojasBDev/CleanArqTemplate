﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseService.Application.UseCases.Get
{
    public class GetUsers
    {
    }
}
