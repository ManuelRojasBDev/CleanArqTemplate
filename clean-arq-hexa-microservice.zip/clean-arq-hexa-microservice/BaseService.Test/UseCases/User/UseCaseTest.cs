using BaseService.Domain.Interfaces.User;
using BaseService.Entities.UseCases.User.Request;
using BaseService.Entities.UseCases.User.Response;
using BaseService.Infrastructure.UseCases.User;
using Moq;

namespace BaseService.Test.Services.UseCase
{
    public class UseCaseTest
    {
        GetUserRequest? getUserRequest;
        GetUserResponse? getUserResponse;
        //Mock<IGetUserInfrastructure> _mockGetUserInfrastructureMock;
        Mock<IGetUserRepository>? _mockGetUserRepository;

        [Fact]
        public async Task GetUser_RequestNull_ReturnsNull()
        {
            // Arrange
            getUserRequest = null;
            _mockGetUserRepository = new Mock<IGetUserRepository>();

            GetUserInfrastructure getUserInfrastructure = new(_mockGetUserRepository.Object);

            // Act
            var result = await getUserInfrastructure.GetUser(getUserRequest);

            // Assert
            Assert.True(result == null);
        }

        [Fact]
        public async Task GetUser_Ok_ReturnsUserById()
        {
            // Arrange
            getUserRequest = new GetUserRequest();
            getUserResponse = new GetUserResponse();
            _mockGetUserRepository = new Mock<IGetUserRepository>();

            _mockGetUserRepository.Setup(r => r.GetUser(It.IsAny<GetUserRequest>())).Returns(Task.FromResult(getUserResponse));
            GetUserInfrastructure getUserInfrastructure = new(_mockGetUserRepository.Object);

            // Act
            var result = await getUserInfrastructure.GetUser(getUserRequest);

            // Assert
            Assert.IsType<GetUserResponse>(result);
        }
    }
}